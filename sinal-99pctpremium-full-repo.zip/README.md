# sinal-99%premium

Repositório pronto para deploy do frontend (Netlify) e backend (Render).

## Resumo
- Frontend em `/frontend`
- Backend em `/backend` (FastAPI)
- `netlify.toml` já configurado para deploy de frontend
- `render.yaml` pronto para importar no Render

---

## Opção A — Deploy rápido (recomendado) — você mesmo, 2 clicks

### 1) Criar repositório no GitHub
- Crie um novo repositório chamado `sinal-99pctpremium`
- Faça upload de todos os arquivos deste ZIP (arraste e solte o conteúdo na raiz do repo)

### 2) Deploy do backend no Render (1 click)
- Acesse https://render.com
- Clique "New" → "Web Service"
- Conecte sua conta GitHub e escolha o repositório `sinal-99pctpremium`
- Preencha:
  - Environment: Python 3
  - Build Command: `pip install -r requirements.txt`
  - Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Clique "Create Web Service"
- Após deploy, copie a URL do backend (ex: https://sinal-99pctpremium-api.onrender.com)

### 3) Deploy do frontend no Netlify (1 click)
- Acesse https://app.netlify.com
- Clique "Add new site" → "Import from Git"
- Conecte seu GitHub e selecione o repositório `sinal-99pctpremium`
- Netlify detectará `netlify.toml` e fará deploy. Após deploy, obtenha a URL pública.

### 4) Ajuste o frontend para apontar ao backend
- No repo, abra `frontend/app.js`
- Substitua `REPLACE_WITH_BACKEND_URL` por `https://sinal-99pctpremium-api.onrender.com` (a URL que o Render gerou)
- Commit e redeploy (Render/Netlify farão auto deploy)

---

## Opção B — Eu te dou os arquivos e instruções e eu crio um deploy button
Se preferir eu gero instruções mais automáticas (deploy buttons), posso criar um README com o botão "Deploy to Netlify" e "Import to Render" — mas ambos dependem do repositório estar no GitHub conectado ao seu perfil.

---

## Observações
- Eu não tenho acesso às suas contas. Você precisará autorizar o GitHub/Netlify/Render.
- Depois que o backend estiver online e você ajustar `frontend/app.js`, o frontend Netlify se conectará corretamente.
