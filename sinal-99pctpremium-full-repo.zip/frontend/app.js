// Edit API_URL after you deploy the backend (see README)
const API_URL = "REPLACE_WITH_BACKEND_URL";

async function testAPI() {
    const out = document.getElementById("result");
    out.innerText = "Consultando API...";
    try {
        const res = await fetch(`${API_URL}/status`);
        const data = await res.json();
        document.getElementById("status").innerText = "Frontend conectado";
        out.innerText = JSON.stringify(data, null, 2);
    } catch (e) {
        document.getElementById("status").innerText = "Erro ao conectar com API";
        out.innerText = e.toString();
    }
}

console.log("Frontend loaded for sinal-99%premium");